//
//  Application Methods.swift
//  VirtualTourist
//
//  Created by Jay Gabriel on 10/21/17.
//  Copyright © 2017 Jay Gabriel. All rights reserved.
//

import UIKit

func showAlert(title: String, message: String) {
    // Displays a dismissable alert to the user.
    
    let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
    alert.addAction(UIAlertAction(title: Constants.AlertMessages.Dismiss, style: .default))
    
    if var currentViewController = UIApplication.shared.keyWindow?.rootViewController {
        while let presentedViewController = currentViewController.presentedViewController {
            currentViewController = presentedViewController
        }
        currentViewController.present(alert, animated: true, completion: nil)
    }
}
