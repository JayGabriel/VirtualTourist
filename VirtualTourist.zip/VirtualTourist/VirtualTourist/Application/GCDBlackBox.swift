//
//  GCDBlackBox.swift
//  VirtualTourist
//
//  Created by Jay Gabriel on 10/16/17.
//  Copyright © 2017 Jay Gabriel. All rights reserved.
//

import UIKit

func performUIUpdatesOnMain(_ updates: @escaping () -> Void) {
    DispatchQueue.main.async {
        updates()
    }
}

