//
//  Pin+CoreDataClass.swift
//  VirtualTourist
//
//  Created by Jay Gabriel on 10/20/17.
//  Copyright © 2017 Jay Gabriel. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Pin)
public class Pin: NSManagedObject {

}
