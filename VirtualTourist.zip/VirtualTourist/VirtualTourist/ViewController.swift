//
//  ViewController.swift
//  VirtualTourist
//
//  Created by Jay Gabriel on 10/20/17.
//  Copyright © 2017 Jay Gabriel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

