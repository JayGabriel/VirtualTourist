//
//  FlickrAPI.swift
//  VirtualTourist
//
//  Created by Jay Gabriel on 10/16/17.
//  Copyright © 2017 Jay Gabriel. All rights reserved.
//

import Foundation

class FlickrAPI {
    
    static let sharedInstance = FlickrAPI()
    
    func loadPhotos(latitude: Double, longitude: Double, _ methodParameters: [String: AnyObject], completionHandlerForLoading: @escaping (_ success: Bool, _ errorString: String?, _ resultArray: [String]?) -> Void) {
        // Starts two network requests to Flickr. Upon completion an escaping closure is passed.
        // (1) The first request obtains JSON data describing the photos with the given location. A random page is selected based on the number of pages.
        // (2) The second request selects photos from the page sent from the first request. This request then returns an array of image URLs the invoking method (TravelLocationsViewController.swift)
        
        let session = URLSession.shared
        let request = URLRequest(url: flickrURLFromParameters(methodParameters))
        
        let task = session.dataTask(with: request) { (data, response, error) in
            
            guard (error == nil) else {
                completionHandlerForLoading(false, error?.localizedDescription, nil)
                return
            }
            
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode <= 299 else {
                completionHandlerForLoading(false, error?.localizedDescription, nil)
                return
            }
            
            guard let data = data else {
                completionHandlerForLoading(false, error?.localizedDescription, nil)
                return
            }
            
            // Parse data
            let parsedResult: [String:AnyObject]!
            do {
                parsedResult = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! [String:AnyObject]
            } catch {
                completionHandlerForLoading(false, Constants.AlertMessages.ParseError, nil)
                return
            }
            
            guard let stat = parsedResult[Constants.FlickrResponseKeys.Status] as? String, stat == Constants.FlickrResponseValues.OKStatus else {
                completionHandlerForLoading(false, Constants.AlertMessages.ParseError, nil)
                return
            }
            
            guard let photosDictionary = parsedResult[Constants.FlickrResponseKeys.Photos] as? [String:AnyObject] else {
                completionHandlerForLoading(false, Constants.AlertMessages.ParseError, nil)
                return
            }
            
            guard let totalPages = photosDictionary[Constants.FlickrResponseKeys.Pages] as? Int else {
                completionHandlerForLoading(false, Constants.AlertMessages.ParseError, nil)
                return
            }
            
            // Obtain a random page number and pass it into the second network request
            let randomPage = (self.randomNumberArrayGeneratorNoDuplicates(count: 1, upperBound: totalPages)).first!
            
            var methodParametersWithPage = methodParameters
            methodParametersWithPage[Constants.FlickrParameterKeys.Page] = randomPage as AnyObject?
            
            self.loadPhotosOnPage(page: randomPage, latitude: latitude, longitude: longitude, methodParametersWithPage, completionHandlerForLoading: completionHandlerForLoading)
            
        }
        task.resume()
        
    }
    
    func loadPhotosOnPage(page: Int, latitude: Double, longitude: Double, _ methodParameters: [String: AnyObject], completionHandlerForLoading: @escaping (_ success: Bool, _ errorString: String?, _ resultArray: [String]?) -> Void) {
        // Loads a number of random image data contained in the given page from the first network request, loadPhotos(_:). If successful, returns the array of image URLs.
        
        let session = URLSession.shared
        let request = URLRequest(url: flickrURLFromParameters(methodParameters))
        
        let task = session.dataTask(with: request) { (data, response, error) in
            
            guard (error == nil) else {
                completionHandlerForLoading(false, error?.localizedDescription, nil)
                return
            }
            
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode <= 299 else {
                completionHandlerForLoading(false, Constants.AlertMessages.StatusError, nil)
                return
            }
            
            guard let data = data else {
                completionHandlerForLoading(false, Constants.AlertMessages.ParseError, nil)
                return
            }
            
            // Parse data
            let parsedResult: [String:AnyObject]!
            do {
                parsedResult = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! [String:AnyObject]
            } catch {
                completionHandlerForLoading(false, Constants.AlertMessages.ParseError, nil)
                return
            }
            
            guard let stat = parsedResult[Constants.FlickrResponseKeys.Status] as? String, stat == Constants.FlickrResponseValues.OKStatus else {
                completionHandlerForLoading(false, Constants.AlertMessages.ParseError, nil)
                return
            }
            
            guard let photosDictionary = parsedResult[Constants.FlickrResponseKeys.Photos] as? [String:AnyObject] else {
                completionHandlerForLoading(false, Constants.AlertMessages.ParseError, nil)
                return
            }
            
            guard let photosArray = photosDictionary[Constants.FlickrResponseKeys.Photo] as? [[String:AnyObject]] else {
                completionHandlerForLoading(false, Constants.AlertMessages.ParseError, nil)
                return
            }
            
            // Set the photo totals
            let resultCount = photosArray.count
            var desiredPhotoCount = Constants.ApplicationPreferences.DesiredPhotoCount
            
            // If the number of totalPhotoCount is less than desiredPhotoCount, adjust
            if resultCount < desiredPhotoCount {
                desiredPhotoCount = resultCount
            }
            
            // Obtain indeces and create an array of URLs
            let randomIndeces = self.randomNumberArrayGeneratorNoDuplicates(count: desiredPhotoCount, upperBound: resultCount)
            var imagePathStrings = [String]()
            
            // Append URLs
            for i in 0..<desiredPhotoCount {
                let currentImage = photosArray[randomIndeces[i]]
                guard let urlForCurrentImage = currentImage[Constants.FlickrResponseKeys.MediumURL] as? String else {
                    completionHandlerForLoading(false, Constants.AlertMessages.ParseError, nil)
                    return
                }
                imagePathStrings.append(urlForCurrentImage)
                
            }
            
            // Return the closure if there is data
            if imagePathStrings.count == 0 {
                completionHandlerForLoading(false, Constants.AlertMessages.CountError, nil)
            } else {
                completionHandlerForLoading(true, nil, imagePathStrings)
                
            }
        }
        task.resume()
        
    }
    
    func flickrURLFromParameters(_ parameters: [String:AnyObject]) -> URL {
        // Creates valid URL components from the given parameters.
        
        var components = URLComponents()
        components.scheme = Constants.Flickr.APIScheme
        components.host = Constants.Flickr.APIHost
        components.path = Constants.Flickr.APIPath
        components.queryItems = [URLQueryItem]()
        
        for (key, value) in parameters {
            let queryItem = URLQueryItem(name: key, value: "\(value)")
            components.queryItems!.append(queryItem)
        }
        
        return components.url!
    }
    
    func convertCoordinates(latitude: Double, longitude: Double) -> String {
        // Converts latitude and longitude to a Flickr API suitable format.
        
        let minimumLon = max(longitude - Constants.Flickr.SearchBBoxHalfWidth, Constants.Flickr.SearchLonRange.0)
        let minimumLat = max(latitude - Constants.Flickr.SearchBBoxHalfHeight, Constants.Flickr.SearchLatRange.0)
        let maximumLon = min(longitude + Constants.Flickr.SearchBBoxHalfWidth, Constants.Flickr.SearchLonRange.1)
        let maximumLat = min(latitude + Constants.Flickr.SearchBBoxHalfHeight, Constants.Flickr.SearchLatRange.1)
        
        return "\(minimumLon),\(minimumLat),\(maximumLon),\(maximumLat)"
    }
    
    func randomNumberArrayGeneratorNoDuplicates(count: Int, upperBound: Int) -> [Int] {
        // Generates an array of random numbers. upperBound must not be less than count.
        
        var randomNumArr = [Int]()
        
        for _ in 0..<count {
            
            // Generate a random number
            var randomNum = arc4random_uniform(UInt32(upperBound))
            var verified = false
            
            // Check if that number is in the array
            if (verify(num: Int(randomNum), numArray: randomNumArr)) {
                randomNumArr.append(Int(randomNum))
                verified = true
            } else {
                while(!verified) {
                    randomNum = arc4random_uniform(UInt32(upperBound))
                    verified = verify(num: Int(randomNum), numArray: randomNumArr)
                }
                randomNumArr.append(Int(randomNum))
            }
        }
        
        return randomNumArr
    }
    
    func verify(num: Int, numArray: [Int]) -> Bool {
        // Helper method to verify if a the given array is unique.
        
        for i in 0..<numArray.count {
            if num == numArray[i] {
                return false
            }
        }
        return true
    }
    
}




